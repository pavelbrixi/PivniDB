from sqlalchemy import create_engine, text
from sqlalchemy import Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
from local_settings import users

# PŘIHLÁŠENÍ

while True:
    username = input("Zadejte uživatelské jméno: ")
    password = input("Zadejte heslo: ")
    if username in users and users[username] == password:
        print("Přihlášení proběhlo úspěšně!")
        break
    else:
        print("Chyba: Neplatná kombinace uživatelského jména a hesla.")
        continue

# SPUŠTĚNÍ SEZENÍ

engine = create_engine(f'postgresql+psycopg2://{username}:{password}@localhost:5432/PivniDB')

Base = declarative_base()

Session = sessionmaker(bind=engine)
session = Session()

# TŘÍDY TABULEK

class sklad(Base):
    __tablename__ = 'sklad'

    skladid = Column(Integer, primary_key=True)
    surovina = Column(String)
    mnozstvi = Column(Float)
    jednotka = Column(String)
    pivovarid = Column(Integer, ForeignKey('pivovary.pivovarid'))

    def __repr__(self):
        return f"<sklad(skladid={self.skladid}, surovina='{self.surovina}', mnozstvi={self.mnozstvi}, jednotka={self.jednotka}, pivovarid={self.pivovarid})>"

class skladLog(Base):
    __tablename__ = 'sklad_log'

    logid = Column(Integer, primary_key=True)
    cas_zmeny = Column(String) 
    akce = Column(String)
    surovina = Column(String)
    skladid = Column(Integer, ForeignKey('sklad.skladid'))
    puvodni_mnozstvi = Column(Float)
    nove_mnozstvi = Column(Float)

    def __repr__(self):
        return f"<sklad(cas_zmeny={self.cas_zmeny}, akce='{self.akce}', surovina={self.surovina}, puvodni_mnozstvi={self.puvodni_mnozstvi}, nove_mnozstvi={self.nove_mnozstvi})>"

class zamestnanci(Base):
    __tablename__ = 'zamestnanci'

    zamestnanecid = Column(Integer, primary_key=True)
    jmeno_a_prijmeni = Column(String)
    pozice = Column(String)
    uzivatelske_jmeno = Column(String)
    pivovarid = Column(Integer, ForeignKey('pivovary.pivovarid'))
    nadrizena_osoba = Column(Integer)
    
    def __repr__(self):
        return f"<Zamestnanci(jmeno_a_prijmeni='{self.jmeno_a_prijmeni}', pozice='{self.pozice}', uzivatelske_jmeno='{self.uzivatelske_jmeno}' pivovarid='{self.pivovarid}', nadrizena_osoba='{self.nadrizena_osoba}')>"
    
class pivovary(Base):
    __tablename__ = 'pivovary'
    pivovarid = Column(Integer, primary_key=True)
    nazev = Column(String)
    lokace = Column(String)
    zalozen = Column(Integer)

# INFORMACE O PRÁVĚ PŘIHLÁŠENÉM UŽIVATELI

aktualni_zamestnanec = (
    session.query(zamestnanci, pivovary)
    .join(pivovary, zamestnanci.pivovarid == pivovary.pivovarid)
    .filter(zamestnanci.uzivatelske_jmeno == username)
    .first()
)

# UVÍTACÍ HLÁŠKA

print("Vítej uživateli,", aktualni_zamestnanec.zamestnanci.jmeno_a_prijmeni)
print("Tvá pozice:", aktualni_zamestnanec.zamestnanci.pozice, "v pivovaru", aktualni_zamestnanec.pivovary.nazev)

# NAVIGACE

while True:

    navigace = input("Zadejte příkaz: ")

    if navigace == "help":
        
        # NÁPOVĚDA

        print("sklad     - zobrazí seznam skladových zásob")
        print("sklad_log - zobrazí poslední změny ve skladu")
        print("logout    - odhlášení")

    elif navigace == "sklad":

        #SKLAD

        stav_skladu = session.query(sklad).all()

        print("Sklad pivovaru", aktualni_zamestnanec.pivovary.nazev)

        for zaznam in stav_skladu:
            print(f"{zaznam.surovina} - {zaznam.mnozstvi}{zaznam.jednotka}")

    elif navigace == "sklad_log":
        
        # SKLAD_LOG

        sklad_logs = session.query(skladLog).all()

        print("Přehled skladovém hospodářství pivovaru ", aktualni_zamestnanec.pivovary.nazev)

        for zaznam in sklad_logs:
            if zaznam.nove_mnozstvi > zaznam.puvodni_mnozstvi:
                # DODÁVKA
                dodavka = zaznam.nove_mnozstvi - zaznam.puvodni_mnozstvi
                print(f"DODÁVKA suroviny: {zaznam.surovina} + {dodavka} | Původní množství: {zaznam.puvodni_mnozstvi}, Nové množství: {zaznam.nove_mnozstvi}")
            elif zaznam.nove_mnozstvi < zaznam.puvodni_mnozstvi:
                # SPOTŘEBOVÁNÍ
                spotrebovani = zaznam.puvodni_mnozstvi - zaznam.nove_mnozstvi
                print(f"SPOTŘEBOVÁNÍ suroviny: {zaznam.surovina} - {spotrebovani} | Původní množství: {zaznam.puvodni_mnozstvi}, Nové množství: {zaznam.nove_mnozstvi}")
    elif navigace == "logout":
        break
    else:
        print("Neplatný příkaz")
