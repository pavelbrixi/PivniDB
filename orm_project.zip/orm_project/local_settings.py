users = {
    "postgres" : "toor",
    "skladadmin" : "sklad123",
    "jnovak" : "heslo123",
    "pdvorakova" : "tajneheslo",
    "ksvoboda" : "mojeheslo",
    "anovotna" : "admin123",
    "pmaly" : "12345"
}